-- Ʈ���� : ����, ����, ���� ���� �� �ķ� �ڵ�����Ǵ� ���α׷�

create or replace trigger emp_log
after insert or update or delete on employees for each row
declare

begin
    if inserting then 
        insert into emp_backup values(:new.employee_id,:new.first_name,
        :new.last_name,:new.email,:new.phone_number,:new.hire_date,:new.job_id,
        :new.salary,:new.commission_pct,:new.manager_id,:new.department_id, sysdate,
        '����');
    elsif updating then
      insert into emp_backup values(:old.employee_id,:old.first_name,
        :old.last_name,:old.email,:old.phone_number,:old.hire_date,:old.job_id,
        :old.salary,:old.commission_pct,:old.manager_id,:old.department_id, sysdate,
        '����');
      elsif deleting then
      insert into emp_backup values(:old.employee_id,:old.first_name,
        :old.last_name,:old.email,:old.phone_number,:old.hire_date,:old.job_id,
        :old.salary,:old.commission_pct,:old.manager_id,:old.department_id, sysdate,
        '����');
    else
        dbms_output.put_line('�۾��� �߸� �Ǿ����ϴ�.');
    end if;
end;


create table emp_backup
as
select * from e where 1<>1;

alter table emp_backup add ev_date date;
alter table emp_backup add bigo varchar2(30);

insert into e values(
301,'ȫ','�浿','honggildong','010-1111-1111',sysdate,'IT_PROG',3000,null,153,80);

select * from emp_backup;
delete from e
where employee_id=301;

update e
set salary =4500
where employee_id=301;

select * from emp_backup;