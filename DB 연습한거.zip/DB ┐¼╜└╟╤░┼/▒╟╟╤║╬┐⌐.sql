select * from e;
select * from free_board;
update free_board
set read_count = 1;
commit;

-- savepoint, rollback, commit ����

-- user ����
create user djit111 identified by 12345;

-- �ý��� ����

create user djit identified by 12345;
GRANT CONNECT TO DJIT;
GRANT RESOURCE TO DJIT;
GRANT CREATE USER TO DJIT;
grant create user to djit with admin option;

-- DJIT

CREATE TABLE TEST(
ID NUMBER,
NAME VARCHAR2(30));

create user joong identified by 12345;

grant create user to hr;



